# (c) 2023 Michael Fitzgerald (mpfitz@ucla.edu)
#
# Code for performing an N-body integration.
#

import numpy as np

# useful constants
AU = 1.496e13      # [cm]    astronomical unit
pc = 3.086e18      # [cm]    parsec
Msol = 1.989e33    # [g]     Solar mass
Mjup = 1.899e30    # [g]     Jupiter mass
Mearth = 5.9742e27 # [g]     Earth mass
yr = 3.15576e7     # [s]     year


# starting parameters
# NOTE:  these will be 2d arrays, with the first dimension being the number of bodies, and the second being dimension 3 (for each spatial direction)
# If you are unsure how to create numpy arrays
X = # [cm]
V = # [cm/s]
M = # [g]

# getting barycentric position and velocity
from astropy import units as u
from astropy.time import Time
apt = Time('2025-10-15 00:00') # starting time
from astropy.coordinates import get_body_barcentric_posvel

# NOTE:  this demonstrates how to get the position of the Sun.  You'll need to do this for each body.  The code here assumes the Sun is the first body in the list (index 0)
pos, vel = get_body_barycentric_posvel('sun', apt)
X[0,:] = pos.xyz.to(u.cm).value # [cm]
V[0,:] = vel.xyz.to(u.cm/u.s).value # [cm/s]


# instantiate random number generator
seed = 259469 # seed for rng
rng = np.random.default_rng(seed=seed)

# adding randomness to starting parameters
#  NOTE  will need to do this for each statistical trial
sig_X = # [cm]
sig_V = # [cm/s]
X += rng.normal(scale=sig_X, size=X.shape)
V += rng.normal(scale=sig_V, size=V.shape)

# integration parameters
n_step =
dt = # [s]


from accel import get_accel
acc = get_accel(X, M) # initial accelerations

# integrating this trial
for i in range(n_step):

    # first step of leapfrog, update velocities
    V += acc * dt/2.

    # update positions
    X += V * dt

    # update accelerations
    acc = get_accel(X, M)

    # 2nd step of leapfrog, update velocities
    V += acc * dt/2.


    # save position and velocity vectors, and timestep
    
    # potential energy?  defer for future

    # calculate kinetic energy for each body
    

# NOTE  there is currently no structure above for running multiple trials, or plotting, or storing results in a pandas data frame.
