import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import median_abs_deviation
from multiprocessing import Pool
from datetime import datetime
import logging
import os

def process_order(ordernumber, basename='WASP33_nov21_rereduced_fluxes_coadded_order_',plot=False):
	data = np.load(basename+str(ordernumber)+'.npy')
	logging.info('Loaded file: ' + basename+str(ordernumber)+'.npy')
	if plot:
		plt.imshow(data,aspect=15,vmin=0,vmax=1e4)
		plt.show()
	# Scale each exposure to a consistent median
	for i in range(data.shape[0]):
		data[i] = data[i]/np.nanmedian(data[i])
	# Now we want to make the median over the time series (y-axis)
	medspec = np.nanmedian(data,axis=0)
	# Now devide each spectrum in the time series by its median
	for i in range(data.shape[0]):
		data[i] = data[i]/medspec
	# And let's mask outliers. Use a boolean index for speed
	threshold = 6*median_abs_deviation(data.flatten())
	data[np.abs(data-1)>threshold] = np.nan	

	if plot:
		plt.imshow(data,aspect=15,vmin=0.95,vmax=1.05)
		plt.show()
	logging.info('Done with ' + basename+str(ordernumber)+'.npy')
	return data

if __name__ == '__main__':
	logging.basicConfig(filename='logfile.log',level=logging.INFO)
	
	# write a simple pool version to process the data in parallel
	# fixme

	